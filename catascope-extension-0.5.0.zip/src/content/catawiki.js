// Catawiki のロットページを閲覧したとき、ロット情報を落札データベースに蓄積する（表示は変えない）
(() => {
  const nd = document.getElementById('__NEXT_DATA__');
  if (!nd || !/\/l\/\d+/.test(location.pathname)) return;
  const send = () => chrome.runtime.sendMessage({ type: 'ingestLot', html: nd.outerHTML, url: location.href.split('?')[0] }, () => void chrome.runtime.lastError);
  setTimeout(send, 1500);
})();
