// Service Worker: 検索パイプライン・ロット取得・キャッシュ・メッセージ処理
import { getConfig } from './lib/config.js';
import { toEnglishQuery, extractModelNumbers } from './lib/dict.js';
import { searchActiveLots, fetchLots, lotIdFromUrl, parseLotPage } from './lib/catawiki.js';
import { findSoldLotsByText, findLotsByImage, uploadCrop, searchDbLots, ingestLots } from './lib/serp.js';
import { getRates } from './lib/rates.js';
import { bumpUsage, getUsage } from './lib/usage.js';

const LOT_CACHE_TTL = 7 * 24 * 60 * 60 * 1000;

async function cacheGet(ids) {
  const keys = ids.map(id => 'lot_' + id);
  const got = await chrome.storage.local.get(keys);
  const out = {};
  for (const id of ids) {
    const v = got['lot_' + id];
    if (v && Date.now() - v.fetchedAt < LOT_CACHE_TTL) out[id] = v;
  }
  return out;
}
async function cachePut(lots) {
  const obj = {};
  for (const l of lots) if (l && l.id && !l.error) obj['lot_' + l.id] = l;
  if (Object.keys(obj).length) await chrome.storage.local.set(obj);
}

function scoreLot(lot, models, queryWords) {
  const t = (lot.title + ' ' + lot.subtitle).toUpperCase();
  let s = 0;
  if (models.some(m => t.includes(m))) s += 100;
  for (const w of queryWords) if (w.length > 2 && t.includes(w)) s += 3;
  if (lot.sold) s += 5;
  return s;
}

// 検索本体
export async function runSearch({ query, rawTitle, imageUrl, source }) {
  const cfg = await getConfig();
  const englishQuery = rawTitle ? toEnglishQuery(rawTitle) : query;
  const models = extractModelNumbers((rawTitle || '') + ' ' + (query || ''));
  const queryWords = englishQuery.toUpperCase().split(/\s+/).filter(Boolean);
  const notes = [];

  // 1) 過去落札ロットの候補URL
  let candidates = [];
  let titlesFromImage = [];
  let usage = null;
  if (imageUrl) {
    const r = await findLotsByImage(cfg, imageUrl);
    candidates = r.lots; titlesFromImage = r.titles; usage = r.usage;
    if (r.noProvider) notes.push('画像検索にはライセンスキーの設定が必要です（設定画面）');
    await bumpUsage('image');
    // 画像から候補が少なければ、類似商品タイトルでテキスト検索
    if (candidates.length < 5 && titlesFromImage[0]) {
      const r2 = await findSoldLotsByText(cfg, toEnglishQuery(titlesFromImage[0]), cfg.maxSold);
      const seen = new Set(candidates.map(c => c.id));
      for (const c of r2.lots) if (!seen.has(c.id)) candidates.push(c);
    }
  } else {
    const r = await findSoldLotsByText(cfg, englishQuery, cfg.maxSold);
    candidates = r.lots; usage = r.usage;
    if (r.noProvider) notes.push('落札履歴の検索にはライセンスキーの設定が必要です（設定画面）。出品中のみ表示しています');
    await bumpUsage('text');
  }
  candidates = candidates.slice(0, cfg.maxSold);

  // 1.5) 落札データベース（蓄積済みロット）。終了済みは確定データなので再取得しない
  const db = imageUrl ? { lots: [], dbTotal: 0 } : await searchDbLots(cfg, englishQuery, cfg.maxSold * 2);
  const dbClosed = db.lots.filter(l => l.closed);
  const dbClosedIds = new Set(dbClosed.map(l => l.id));
  // DB にある出品中ロットは候補に加えて再取得（終了していれば更新される）
  const candIds = new Set(candidates.map(c => c.id));
  for (const l of db.lots) if (!l.closed && !candIds.has(l.id)) { candidates.push({ id: l.id, url: l.url, title: l.title }); candIds.add(l.id); }
  candidates = candidates.filter(c => !dbClosedIds.has(c.id));

  // 2) ロットページ取得（キャッシュ優先）
  const ids = candidates.map(c => c.id);
  const cached = await cacheGet(ids);
  const toFetch = candidates.filter(c => !cached[c.id]);
  let fetched = [];
  if (toFetch.length) {
    fetched = await fetchLots(toFetch.map(c => c.url), { concurrency: cfg.fetchConcurrency, delayMs: cfg.fetchDelayMs });
    if (fetched.some(f => f?.error === 'catawiki_blocked')) notes.push('一時的に取得が制限されています。しばらく待ってから再検索してください');
    await cachePut(fetched);
    ingestLots(cfg, fetched).catch(() => {});   // データベースに蓄積（失敗しても検索は続行）
  }
  const lotMap = { ...cached };
  for (const f of fetched) if (f && f.id) lotMap[f.id] = f;
  let sold = ids.map(id => lotMap[id]).filter(l => l && !l.error);
  for (const l of dbClosed) if (!lotMap[l.id]) sold.push(l);

  // 3) 出品中（関連商品）
  let active = [];
  if (cfg.includeActive) {
    try { active = await searchActiveLots(englishQuery || query); }
    catch (e) { notes.push('出品中ロットの取得に失敗: ' + e.message); }
  }
  const soldIds = new Set(sold.map(l => l.id));
  active = active.filter(a => !soldIds.has(a.id));

  // 4) スコアリング・統計
  for (const l of sold) { l.score = scoreLot(l, models, queryWords); l.exactModel = models.some(m => (l.title + ' ' + l.subtitle).toUpperCase().includes(m)); }
  for (const l of active) { l.score = scoreLot(l, models, queryWords); l.exactModel = models.some(m => (l.title + ' ' + l.subtitle).toUpperCase().includes(m)); }
  sold.sort((a, b) => b.score - a.score || (new Date(b.endTime || 0) - new Date(a.endTime || 0)));
  active.sort((a, b) => b.score - a.score);

  const soldOnly = sold.filter(l => l.sold && l.priceEUR != null);
  const prices = soldOnly.map(l => l.priceEUR).sort((a, b) => a - b);
  const stats = {
    closedCount: sold.filter(l => l.closed).length,
    soldCount: soldOnly.length,
    soldRate: sold.filter(l => l.closed).length ? soldOnly.length / sold.filter(l => l.closed).length : null,
    avgEUR: prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : null,
    medianEUR: prices.length ? prices[Math.floor(prices.length / 2)] : null,
    minEUR: prices[0] ?? null,
    maxEUR: prices[prices.length - 1] ?? null
  };

  const rates = await getRates();
  const localUsage = await getUsage();
  return { query: query || rawTitle, englishQuery, models, sold, active, stats, rates, notes, usage: usage || localUsage, source, titlesFromImage, db: { hits: dbClosed.length, total: db.dbTotal } };
}

// 検索履歴（最大5件）
async function pushHistory(q) {
  if (!q) return;
  const { history = [] } = await chrome.storage.local.get('history');
  const h = [q, ...history.filter(x => x !== q)].slice(0, 5);
  await chrome.storage.local.set({ history: h });
}

function openResults(params) {
  const url = chrome.runtime.getURL('src/results/results.html') + '?' + new URLSearchParams(params).toString();
  chrome.tabs.create({ url });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case 'search': {
          const res = await runSearch(msg);
          await pushHistory(msg.query || msg.rawTitle);
          sendResponse({ ok: true, data: res });
          break;
        }
        case 'ingestLot': {
          try { const cfg = await getConfig(); const lot = parseLotPage(msg.html, msg.url); await cachePut([lot]); const n = await ingestLots(cfg, [lot], 'browse'); sendResponse({ ok: true, stored: n }); }
          catch (e) { sendResponse({ ok: false, error: e.message }); }
          break;
        }
        case 'openResults': {
          openResults(msg.params);
          sendResponse({ ok: true });
          break;
        }
        case 'lensFromCrop': {
          const cfg = await getConfig();
          const url = await uploadCrop(cfg, msg.dataUrl);
          openResults({ imageUrl: url, source: msg.source || 'crop' });
          sendResponse({ ok: true, url });
          break;
        }
        case 'fetchImageAsDataUrl': {
          // content script からのクロスオリジン画像取得（canvas汚染回避）
          const r = await fetch(msg.url);
          const b = await r.blob();
          const dataUrl = await new Promise((resolve, reject) => { const fr = new FileReader(); fr.onload = () => resolve(fr.result); fr.onerror = reject; fr.readAsDataURL(b); });
          sendResponse({ ok: true, dataUrl });
          break;
        }
        case 'getRates': sendResponse({ ok: true, data: await getRates() }); break;
        case 'getUsage': sendResponse({ ok: true, data: await getUsage() }); break;
        default: sendResponse({ ok: false, error: 'unknown message' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message || String(e) });
    }
  })();
  return true; // async
});

// 右クリックメニュー：選択テキスト / 画像 から検索
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'cs-text', title: 'CataScope: 「%s」の落札相場を検索', contexts: ['selection'] });
  chrome.contextMenus.create({ id: 'cs-image', title: 'CataScope: この画像で類似落札を検索', contexts: ['image'] });
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === 'cs-text' && info.selectionText) openResults({ rawTitle: info.selectionText, source: 'context' });
  if (info.menuItemId === 'cs-image' && info.srcUrl) openResults({ imageUrl: info.srcUrl, source: 'context' });
});
