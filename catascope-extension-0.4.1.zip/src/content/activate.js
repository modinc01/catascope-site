// アクティベーションページ（https://catascope.luxroute.net/activate?key=CS-XXXX）:
// URL のキーを拡張の設定に保存し、ページに結果を表示する
(async () => {
  const key = new URLSearchParams(location.search).get('key') || '';
  const box = document.getElementById('cs-activate-status');
  const show = (ok, msg) => { if (box) { box.textContent = msg; box.className = ok ? 'ok' : 'ng'; } };
  if (!/^CS-[A-Z0-9]{8}-[A-Z0-9]{8}$/.test(key)) return show(false, 'ライセンスキーがURLに含まれていません。メールのリンクをそのまま開いてください。');
  try {
    await chrome.storage.sync.set({ licenseKey: key, backendUrl: 'https://catascope.luxroute.net' });
    show(true, `ライセンスキー ${key} を設定しました。ヤフオク・エコオク・メルカリの商品ページで「落札相場を見る」を押してください。`);
  } catch (e) { show(false, '設定に失敗しました: ' + e.message); }
})();
