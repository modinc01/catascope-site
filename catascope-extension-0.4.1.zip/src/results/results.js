import { convert, formatMoney } from '../lib/rates.js';
const $ = s => document.querySelector(s);
const params = new URLSearchParams(location.search);
let data = null;
let currency = 'JPY';
let feeRate = 12.5;
const filter = { cond: null, soldOnly: false, exactOnly: false, sort: 'new' };

const fmt = eur => formatMoney(convert(eur, currency, data.rates), currency);
const dateStr = iso => { if (!iso) return ''; const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('ja-JP', { year: '2-digit', month: 'numeric', day: 'numeric' }); };
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const median = a => a.length ? a[Math.floor(a.length / 2)] : null;
// "Good condition, used with some signs of wear" → "Good"
const condShort = c => { const m = String(c || '').match(/^(new\/unused|new|mint|excellent|very good|good|fair|poor|as new|unused)/i); return m ? m[1].replace(/\/unused/i, '') : (c ? c.split(/[,，]/)[0].slice(0, 18) : ''); };

function visibleSold() {
  let rows = data.sold.slice();
  if (filter.cond) rows = rows.filter(l => condShort(l.condition) === filter.cond);
  if (filter.soldOnly) rows = rows.filter(l => l.sold);
  if (filter.exactOnly) rows = rows.filter(l => l.exactModel);
  if (filter.sort === 'new') rows.sort((a, b) => new Date(b.endTime || 0) - new Date(a.endTime || 0));
  if (filter.sort === 'high') rows.sort((a, b) => (b.priceEUR ?? -1) - (a.priceEUR ?? -1));
  if (filter.sort === 'low') rows.sort((a, b) => (a.priceEUR ?? 1e12) - (b.priceEUR ?? 1e12));
  return rows;
}

function row(l) {
  const cls = l.closed ? (l.sold ? 'sold' : 'unsold') : 'open';
  const label = l.closed ? (l.sold ? '売れた' : 'リザーブ未達') : '出品中';
  const price = l.priceEUR != null && (l.sold || !l.closed) ? fmt(l.priceEUR) : (l.closed ? `最高入札 ${l.priceEUR != null ? fmt(l.priceEUR) : '—'}` : '—');
  const net = l.sold && l.priceEUR != null ? `<span class="net">手取り ${fmt(l.priceEUR * (1 - feeRate / 100))}</span>` : '';
  const est = l.estimateMin != null ? `見積 ${fmt(l.estimateMin)}〜${fmt(l.estimateMax)}` : '';
  const meta = [l.sellerCountry ? l.sellerCountry.toUpperCase() : '', l.bidCount != null ? `入札 ${l.bidCount >= 10 ? '10+' : l.bidCount}` : ''].filter(Boolean).join(' · ');
  return `<div class="row ${l.exactModel ? 'exact' : ''}">
    <div class="mark"></div>
    <div class="th" data-img="${esc(l.imageLarge || l.image)}"><img src="${esc(l.image)}" alt="" loading="lazy"></div>
    <div class="t"><a href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.title)}</a>${l.exactModel ? '<span class="chip">型番一致</span>' : ''}${l.condition ? `<span class="cond" title="${esc(l.condition)}">${esc(l.condition)}</span>` : ''}<span class="s">${esc(l.subtitle || '')}${meta ? (l.subtitle ? ' · ' : '') + meta : ''}</span></div>
    <div class="res ${cls}">${label}</div>
    <div class="p ${cls}">${price}${net}</div>
    <div class="e">${est}</div>
    <div class="d">${l.closed ? dateStr(l.endTime) : (l.endTime ? '終了 ' + dateStr(l.endTime) : '')}</div>
  </div>`;
}

function summarize(rows) {
  const closed = rows.filter(l => l.closed);
  const soldLots = closed.filter(l => l.sold && l.priceEUR != null);
  const prices = soldLots.map(l => l.priceEUR).sort((a, b) => a - b);
  const hit = median(soldLots.filter(l => l.estimateMin > 0).map(l => l.priceEUR / l.estimateMin).sort((a, b) => a - b));
  // 未達ロットの最高入札も含めた中央値（買い手が実際に付けた値段の目安）
  const bidLots = closed.filter(l => l.priceEUR != null && l.priceEUR > 0);
  const bidMed = median(bidLots.map(l => l.priceEUR).sort((a, b) => a - b));
  return { closed: closed.length, soldN: soldLots.length, rate: closed.length ? soldLots.length / closed.length : null, med: median(prices), min: prices[0] ?? null, max: prices[prices.length - 1] ?? null, hit, bidMed, bidN: bidLots.length };
}

function renderSummary(rows) {
  const v = summarize(rows);
  const stat = (l, val, sub = '') => `<div class="stat"><div class="l">${l}</div><div class="v">${val}</div>${sub ? `<div class="s">${sub}</div>` : ''}</div>`;
  const models = (data.models || []).map(m => `<span class="m">${esc(m)}</span>`).join('');
  let range = '';
  if (v.min != null && v.max != null && v.max > v.min) {
    const pct = x => ((x - v.min) / (v.max - v.min) * 100).toFixed(1) + '%';
    const dots = rows.filter(l => l.sold && l.priceEUR != null).map(l => `<b style="left:${pct(l.priceEUR)}" title="${esc(l.title)} ${fmt(l.priceEUR)}"></b>`).join('');
    range = `<div class="range"><div class="lbl"><span>最安 ${fmt(v.min)}</span><span>落札価格帯（点＝各落札、青い印＝中央値）</span><span>最高 ${fmt(v.max)}</span></div><div class="bar">${dots}<i style="left:${pct(v.med)}"></i></div></div>`;
  }
  $('#summary').innerHTML = `
    <div class="s-head"><span class="q">${esc(data.query || '')}${models}</span><span class="sub">${filter.cond ? `コンディション「${esc(filter.cond)}」で絞り込み中` : '検索語: ' + esc(data.englishQuery || '')}</span></div>
    <div class="s-grid">
      ${stat('落札件数', `${v.soldN} <span style="font-size:13px;font-weight:500">/ ${v.closed} 件</span>`, '売れた / 終了')}
      ${stat('リザーブ到達率', v.rate != null ? Math.round(v.rate * 100) + '%' : '—', '売れた ÷ 終了')}
      ${stat('落札中央値', v.med != null ? fmt(v.med) : '—', v.soldN ? `${v.soldN} 件の売れたロット` : '')}
      ${stat('最高入札の中央値', v.bidMed != null ? fmt(v.bidMed) : '—', `未達を含む終了 ${v.bidN} 件`)}
      ${stat('手取り換算', v.med != null ? fmt(v.med * (1 - feeRate / 100)) : '—', `中央値から手数料 ${feeRate}% を控除`)}
      ${stat('見積達成率', v.hit != null ? Math.round(v.hit * 100) + '%' : '—', '落札価 ÷ 専門家見積の下限')}
    </div>
    ${range}
    <div class="s-foot">為替 €1 = ¥${Math.round(data.rates.JPY)} / $${data.rates.USD?.toFixed(2)}（ECB ${data.rates.date || ''}）· 今月の検索回数 ${data.usage?.text ?? '-'}（画像 ${data.usage?.image ?? '-'}）</div>`;
  $('#summary').hidden = false;
}

function renderFilters() {
  const counts = {};
  for (const l of data.sold) { const c = condShort(l.condition); if (c) counts[c] = (counts[c] || 0) + 1; }
  const conds = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  $('#filters').innerHTML = `
    <span class="lbl">コンディション</span>
    <button class="chip ${filter.cond == null ? 'on' : ''}" data-cond="">すべて<span class="n">${data.sold.length}</span></button>
    ${conds.map(([c, n]) => `<button class="chip ${filter.cond === c ? 'on' : ''}" data-cond="${esc(c)}">${esc(c)}<span class="n">${n}</span></button>`).join('')}
    <span class="sep"></span>
    <button class="chip ${filter.soldOnly ? 'on' : ''}" data-t="soldOnly">売れたのみ</button>
    <button class="chip ${filter.exactOnly ? 'on' : ''}" data-t="exactOnly">型番一致のみ</button>
    <span class="sep"></span>
    <select id="sort"><option value="new" ${filter.sort === 'new' ? 'selected' : ''}>新しい順</option><option value="high" ${filter.sort === 'high' ? 'selected' : ''}>高い順</option><option value="low" ${filter.sort === 'low' ? 'selected' : ''}>安い順</option></select>`;
  $('#filters').hidden = false;
}

function render() {
  document.querySelectorAll('.seg button').forEach(b => b.classList.toggle('on', b.dataset.c === currency));
  const rows = visibleSold();
  renderSummary(rows);
  renderFilters();
  $('#notes').innerHTML = (data.notes || []).map(n => `<div>${esc(n)}</div>`).join('');
  $('#soldCount').textContent = `${rows.length} 件${rows.length !== data.sold.length ? ` / 全 ${data.sold.length} 件` : ''}`;
  $('#activeCount').textContent = data.active.length + ' 件';
  $('#sold').innerHTML = rows.length ? rows.map(row).join('') : `<div class="empty">${data.sold.length ? '条件に合う落札がありません。絞り込みを解除してください。' : '落札履歴が見つかりませんでした。商品名を短くする、型番だけで検索する、などを試してください。'}</div>`;
  $('#active').innerHTML = data.active.length ? data.active.map(row).join('') : '<div class="empty">出品中の競合はありません</div>';
  $('#status').textContent = data.titlesFromImage?.length ? `画像から推定した商品名: ${data.titlesFromImage[0]}` : '';
}

function exportCsv() {
  const rows = visibleSold();
  const head = ['title', 'result', 'price_eur', `price_${currency.toLowerCase()}`, `net_${currency.toLowerCase()}_fee${feeRate}`, 'condition', 'estimate_min_eur', 'estimate_max_eur', 'end_date', 'seller_country', 'model_match', 'url'];
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = rows.map(l => [l.title, l.closed ? (l.sold ? 'sold' : 'unsold') : 'open', l.priceEUR ?? '', l.priceEUR != null ? Math.round(convert(l.priceEUR, currency, data.rates)) : '', l.sold && l.priceEUR != null ? Math.round(convert(l.priceEUR * (1 - feeRate / 100), currency, data.rates)) : '', l.condition, l.estimateMin ?? '', l.estimateMax ?? '', l.endTime ? l.endTime.slice(0, 10) : '', l.sellerCountry, l.exactModel ? 1 : 0, l.url].map(q).join(','));
  const blob = new Blob(['﻿' + [head.join(','), ...lines].join('\n')], { type: 'text/csv' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `catascope_${(data.query || 'search').replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 40)}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function run() {
  const req = { type: 'search', source: params.get('source') || 'results' };
  if (params.get('imageUrl')) req.imageUrl = params.get('imageUrl');
  if (params.get('rawTitle')) req.rawTitle = params.get('rawTitle');
  if (params.get('q')) req.query = params.get('q');
  $('#q').value = req.rawTitle || req.query || '';
  const cfg = await chrome.storage.sync.get({ currency: 'JPY', feeRate: 12.5 });
  currency = cfg.currency; feeRate = Number(cfg.feeRate) || 12.5;
  $('#status').innerHTML = (req.imageUrl ? '画像から類似ロットを探しています' : '直近の落札を集めています') + '<div class="bar"><i></i></div>';
  const res = await chrome.runtime.sendMessage(req);
  if (!res?.ok) { $('#status').textContent = 'エラー: ' + (res?.error || 'unknown'); return; }
  data = res.data;
  document.title = `${data.query} - CataScope 落札相場`;
  render();
}

$('#cur').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; currency = b.dataset.c; chrome.storage.sync.set({ currency }); render(); });
$('#f').addEventListener('submit', e => { e.preventDefault(); const q = $('#q').value.trim(); if (q) location.search = '?' + new URLSearchParams({ rawTitle: q, source: 'results' }); });
$('#filters').addEventListener('click', e => {
  const b = e.target.closest('button.chip'); if (!b) return;
  if (b.dataset.cond !== undefined) filter.cond = b.dataset.cond || null;
  if (b.dataset.t) filter[b.dataset.t] = !filter[b.dataset.t];
  render();
});
$('#filters').addEventListener('change', e => { if (e.target.id === 'sort') { filter.sort = e.target.value; render(); } });
$('#csv').addEventListener('click', exportCsv);
document.addEventListener('click', e => {
  const im = e.target.closest('.th'); if (im) { $('#lbimg').src = im.dataset.img; $('#lightbox').hidden = false; }
  if (e.target.closest('#lightbox')) $('#lightbox').hidden = true;
});
run();
