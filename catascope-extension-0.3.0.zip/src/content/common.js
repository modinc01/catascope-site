// 対応サイト共通：「落札相場を見る」ボタンの設置・タイトル/画像の抽出ヘルパー・範囲選択オーバーレイ
window.CataScope = (() => {
  const toast = (msg, ms = 2500) => { const t = document.createElement('div'); t.className = 'cs-toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ms); };
  const og = (p) => document.querySelector(`meta[property="og:${p}"]`)?.content || '';
  const yen = (s) => { const m = String(s || '').replace(/,/g, '').match(/(\d{3,})/); return m ? Number(m[1]) : null; };
  const LOGO = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="2.6" fill="currentColor"/><path d="M12 1.5v4M12 18.5v4M1.5 12h4M18.5 12h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

  function mount({ getTitle, getImage }) {
    if (document.querySelector('.cs-dock')) return;
    const dock = document.createElement('div');
    dock.className = 'cs-dock';
    dock.innerHTML = `
      <div class="cs-sub">
        <button data-act="camera">画像で探す</button>
        <button data-act="crop">範囲を選んで探す</button>
      </div>
      <button class="cs-main" data-act="title">${LOGO}<span>落札相場を見る</span></button>`;
    document.body.appendChild(dock);
    const base = () => ({ source: location.hostname });
    dock.addEventListener('click', async (e) => {
      const b = e.target.closest('button'); if (!b) return;
      const act = b.dataset.act;
      try {
        if (act === 'title') {
          const title = (getTitle() || og('title') || document.title).trim();
          if (!title) return toast('商品名が取得できませんでした');
          chrome.runtime.sendMessage({ type: 'openResults', params: { rawTitle: title, ...base() } });
        } else if (act === 'camera') {
          const img = getImage() || og('image');
          if (!img) return toast('商品画像が取得できませんでした');
          chrome.runtime.sendMessage({ type: 'openResults', params: { imageUrl: img, rawTitle: (getTitle() || '').trim(), ...base() } });
        } else if (act === 'crop') {
          const img = getImage() || og('image');
          if (!img) return toast('商品画像が取得できませんでした');
          openCrop(img, base());
        }
      } catch (err) { toast('エラー: ' + err.message); }
    });
  }

  async function openCrop(imageUrl, extra) {
    const r = await chrome.runtime.sendMessage({ type: 'fetchImageAsDataUrl', url: imageUrl });
    if (!r?.ok) return toast('画像の読み込みに失敗: ' + (r?.error || ''));
    const ov = document.createElement('div');
    ov.className = 'cs-crop-overlay';
    ov.innerHTML = `<div class="cs-crop-wrap"><img alt=""><div class="cs-sel" hidden></div></div>
      <div class="cs-bar"><span>ドラッグで商品本体だけを囲ってください</span><button class="cs-go">この範囲で探す</button><button class="cs-cancel">キャンセル</button></div>`;
    document.body.appendChild(ov);
    const img = ov.querySelector('img'); img.src = r.dataUrl;
    const sel = ov.querySelector('.cs-sel');
    let start = null, rect = null;
    const pos = (e) => { const b = img.getBoundingClientRect(); return { x: Math.min(Math.max(e.clientX - b.left, 0), b.width), y: Math.min(Math.max(e.clientY - b.top, 0), b.height), b }; };
    img.addEventListener('mousedown', e => { e.preventDefault(); start = pos(e); sel.hidden = false; });
    ov.addEventListener('mousemove', e => { if (!start) return; const p = pos(e); rect = { x: Math.min(start.x, p.x), y: Math.min(start.y, p.y), w: Math.abs(p.x - start.x), h: Math.abs(p.y - start.y) }; Object.assign(sel.style, { left: rect.x + 'px', top: rect.y + 'px', width: rect.w + 'px', height: rect.h + 'px' }); });
    ov.addEventListener('mouseup', () => { start = null; });
    ov.querySelector('.cs-cancel').onclick = () => ov.remove();
    ov.querySelector('.cs-go').onclick = async () => {
      if (!rect || rect.w < 10 || rect.h < 10) return toast('範囲を選択してください');
      const scale = img.naturalWidth / img.getBoundingClientRect().width;
      const c = document.createElement('canvas');
      c.width = Math.round(rect.w * scale); c.height = Math.round(rect.h * scale);
      c.getContext('2d').drawImage(img, rect.x * scale, rect.y * scale, c.width, c.height, 0, 0, c.width, c.height);
      const dataUrl = c.toDataURL('image/jpeg', 0.9);
      ov.querySelector('.cs-go').disabled = true;
      const res = await chrome.runtime.sendMessage({ type: 'lensFromCrop', dataUrl, ...extra });
      ov.remove();
      if (!res?.ok) toast(res?.error === 'backend_required_for_crop' ? '範囲を選んで探すにはバックエンドURLの設定が必要です' : 'エラー: ' + res?.error, 4000);
    };
  }

  return { mount, toast, og, yen };
})();
