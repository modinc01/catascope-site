// メルカリ 商品ページ（SPAなのでURL変化を監視）
(() => {
  const getTitle = () => document.querySelector('h1[data-testid="name"], h1')?.textContent || window.CataScope.og('title');
  const getImage = () => {
    const el = document.querySelector('[data-testid="image-0"] img, [data-testid="carousel"] img, main img');
    return el?.src || window.CataScope.og('image');
  };
  const tryMount = () => { if (/\/item\/|\/shops\/product\//.test(location.pathname)) window.CataScope.mount({ getTitle, getImage }); };
  tryMount();
  let last = location.href;
  new MutationObserver(() => { if (location.href !== last) { last = location.href; document.querySelector('.cs-dock')?.remove(); setTimeout(tryMount, 800); } }).observe(document.body, { childList: true, subtree: true });
})();
