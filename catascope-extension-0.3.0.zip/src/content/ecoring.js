// エコオク（ecoauc.com）商品ページ。2026-09-25 実DOMで確認:
//   URL   /client/auction-items/view/<id>/...
//   題名  .head-title h2 … <small>ブランド</small>(出品番号)タイトル
//   画像  .swiper-slide img[src*="assets.ecoauc.com/images/item"]（4032px 原寸）
(() => {
  const isItemPage = () => /\/auction-items\/view\/\d+/.test(location.pathname);
  const getTitle = () => {
    const h2 = document.querySelector('.head-title h2, h2');
    if (!h2) return window.CataScope.og('title') || '';
    const brand = h2.querySelector('small')?.textContent.trim() || '';
    let t = [...h2.childNodes].filter(n => n.nodeType === Node.TEXT_NODE).map(n => n.textContent).join(' ');
    t = t.replace(/^\s*\(\s*[\w-]+\s*\)\s*/, '').replace(/\s+/g, ' ').trim();   // 先頭の出品番号 (13593_0045)
    if (brand && !t.toUpperCase().startsWith(brand.toUpperCase())) t = brand + ' ' + t;
    // LV等のシリアル（AR0917 形式）は型番と誤認され検索語を汚すので、型番が別にあれば除く
    const toks = t.split(' ');
    const hasModel = toks.some(w => /^[A-Z]{1,3}\d{4,7}[A-Z]{0,2}$/.test(w) && !/^[A-Z]{2}\d{4}$/.test(w));
    if (hasModel) t = toks.filter(w => !/^[A-Z]{2}\d{4}$/.test(w)).join(' ');
    return t;
  };
  const getImage = () => {
    const el = document.querySelector('.swiper-slide-active img[src*="assets.ecoauc.com/images/item"], .swiper-slide img[src*="assets.ecoauc.com/images/item"], img[src*="assets.ecoauc.com/images/item"]');
    return el?.src || window.CataScope.og('image');
  };
  const tryMount = () => { if (isItemPage() && document.querySelector('.head-title h2, h2')) window.CataScope.mount({ getTitle, getImage }); };
  tryMount();
  let last = location.href;
  new MutationObserver(() => { if (location.href !== last) { last = location.href; document.querySelector('.cs-dock')?.remove(); tryMount(); } }).observe(document.documentElement, { childList: true, subtree: true });
})();
