// ヤフオク 商品ページ（2026-09 実DOM: h1 はアトミックCSSクラスのみ、画像は auctions.c.yimg.jp の 1200px）
(() => {
  const getTitle = () => document.querySelector('h1.ProductTitle__text, .ProductTitle__text, h1')?.textContent || '';
  const getImage = () => {
    const legacy = document.querySelector('.ProductImage__image img, .ProductImage img, [class*="ProductImage"] img');
    if (legacy?.src) return legacy.src;
    const imgs = [...document.querySelectorAll('img[src*="auctions.c.yimg.jp/images.auctions.yahoo.co.jp"]')]
      .filter(i => i.naturalWidth >= 300).sort((a, b) => b.naturalWidth - a.naturalWidth);
    return imgs[0]?.src || window.CataScope.og('image');
  };
  window.CataScope.mount({ getTitle, getImage });
})();
