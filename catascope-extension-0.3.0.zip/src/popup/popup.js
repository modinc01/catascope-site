const $ = s => document.querySelector(s);
async function load() {
  const { history = [] } = await chrome.storage.local.get('history');
  $('#history').innerHTML = (history.length ? '<div class="h">最近の検索</div>' : '') + history.map(h => `<a href="#" data-q="${h.replace(/"/g, '&quot;')}">${h}</a>`).join('');
  const u = await chrome.runtime.sendMessage({ type: 'getUsage' });
  if (u?.ok) $('#usage').textContent = `今月 ${u.data.text || 0} 回`;
}
$('#f').addEventListener('submit', e => {
  e.preventDefault();
  const q = $('#q').value.trim();
  if (!q) return;
  chrome.runtime.sendMessage({ type: 'openResults', params: { rawTitle: q, source: 'popup' } });
  window.close();
});
$('#history').addEventListener('click', e => {
  const a = e.target.closest('a'); if (!a) return; e.preventDefault();
  chrome.runtime.sendMessage({ type: 'openResults', params: { rawTitle: a.dataset.q, source: 'history' } });
  window.close();
});
$('#opt').addEventListener('click', e => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
load();
