import { getConfig, setConfig, DEFAULTS } from '../lib/config.js';
const fields = Object.keys(DEFAULTS);
(async () => {
  const cfg = await getConfig();
  for (const k of fields) { const el = document.getElementById(k); if (!el) continue; if (el.type === 'checkbox') el.checked = !!cfg[k]; else el.value = cfg[k]; }
})();
document.getElementById('save').addEventListener('click', async () => {
  const patch = {};
  for (const k of fields) { const el = document.getElementById(k); if (!el) continue; patch[k] = el.type === 'checkbox' ? el.checked : (el.type === 'number' ? Number(el.value) : el.value.trim()); }
  await setConfig(patch);
  document.getElementById('msg').textContent = '保存しました';
  setTimeout(() => document.getElementById('msg').textContent = '', 2000);
});
