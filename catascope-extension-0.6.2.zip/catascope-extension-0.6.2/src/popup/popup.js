const $ = s => document.querySelector(s);
async function load() {
  const { history = [] } = await chrome.storage.local.get('history');
  $('#history').innerHTML = (history.length ? '<div class="h">最近の検索</div>' : '') + history.map(h => `<a href="#" data-q="${h.replace(/"/g, '&quot;')}">${h}</a>`).join('');
  const u = await chrome.runtime.sendMessage({ type: 'getUsage' });
  if (u?.ok) $('#usage').textContent = `今月 ${u.data.text || 0} 回`;
}
$('#f').addEventListener('submit', e => {
  e.preventDefault();
  const q = $('#q').value.trim();
  if (!q) return;
  chrome.runtime.sendMessage({ type: 'openResults', params: { rawTitle: q, source: 'popup' } });
  window.close();
});
$('#history').addEventListener('click', e => {
  const a = e.target.closest('a'); if (!a) return; e.preventDefault();
  chrome.runtime.sendMessage({ type: 'openResults', params: { rawTitle: a.dataset.q, source: 'history' } });
  window.close();
});
$('#opt').addEventListener('click', e => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
$('#refl').addEventListener('click', e => { e.preventDefault(); referral(true); });

// 紹介制度の案内: ライセンス設定後に 1 回ポップアップ（内容はサーバーの /api/referral、閉じたら同じ案内 id は出さない）
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function referral(force = false) {
  const { licenseKey = '', backendUrl = 'https://catascope.luxroute.net' } = await chrome.storage.sync.get(['licenseKey', 'backendUrl']);
  if (!licenseKey) return;
  let { referral: cached, referralDismissed = [] } = await chrome.storage.local.get(['referral', 'referralDismissed']);
  if (force || !cached || Date.now() - (cached.at || 0) > 6 * 3600e3) {
    try { const r = await fetch(backendUrl.replace(/\/$/, '') + '/api/referral', { cache: 'no-store' }); cached = { at: Date.now(), data: await r.json() }; await chrome.storage.local.set({ referral: cached }); } catch {}
  }
  const d = cached && cached.data;
  if (!d || !d.id || d.enabled === false) return;
  if (!force && referralDismissed.includes(d.id)) return;
  $('#ref-title').textContent = d.title || '紹介制度のご案内';
  $('#ref-body').innerHTML = (d.lines || []).map(l => `<p>${esc(l)}</p>`).join('') + (d.steps ? '<ol>' + d.steps.map(x => `<li>${esc(x)}</li>`).join('') + '</ol>' : '') + (d.note ? `<p class="muted">${esc(d.note)}</p>` : '');
  const code = licenseKey.slice(-8);
  $('#ref-code').textContent = code;
  $('#ref-copy').textContent = 'コピー';
  $('#ref-copy').onclick = async () => { try { await navigator.clipboard.writeText(code); $('#ref-copy').textContent = 'コピーしました'; } catch {} };
  $('#ref-close').onclick = async () => { $('#ref').hidden = true; if (!referralDismissed.includes(d.id)) { referralDismissed.push(d.id); await chrome.storage.local.set({ referralDismissed }); } };
  $('#ref').hidden = false;
}
load().then(() => referral());
